export function Pie() {
    const anioActual = new Date().getFullYear()
    return (
        <div>
            <p>{anioActual}</p>
        </div>
    )
}