export function Cabecera() {
    const nombreModulo = "ICS-IA_26_27"
    return (
        <h1>{nombreModulo}</h1>
    )
}